import { useState } from 'react'

function Counter() {

    const [count, setCount] = useState(0)
    const [active, setActive] = useState(false);

    function add() {
        setCount(count + 1);
    }

    function sub() {
        setCount(count - 1);
    }

    function reset() {
        setCount(0);
    }

    function increment5() {
        setCount(count + 5);
    }

    function decrement5() {
        setCount(count - 5);
    }

    function set100() {
        setCount(100);
    }
    
    function activate() {
        setActive(!active)
    }

    return (
        <>
            <div>
                <p>Licznik {count}</p>

                <button onClick={add}>
                    Zwiększ
                </button>

                <button onClick={sub}>
                    Zmniejsz
                </button>

                <button onClick={reset}>
                    Resetuj
                </button>

                <button onClick={increment5}>
                    Zwiększ o 5
                </button>

                <button onClick={decrement5}>
                    Zmniejsz o 5
                </button>

                <button onClick={set100}>
                    Ustaw na 100
                </button>

                <p>{active ? "Aktywny" : "Nieaktywny"}</p>

                <button onClick={activate}>
                    Aktywuj/Deaktywuj
                </button>

            </div>
        </>
    );
}

export default Counter;
