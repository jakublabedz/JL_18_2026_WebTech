import { useState } from 'react'
import './App.css'
import Checkbox from './components/Checkbox.jsx'
import Filter from './components/Filter.jsx'

function App() {
  return (
    <>
      <Checkbox />
      <Filter />
    </>
  )
}



export default App